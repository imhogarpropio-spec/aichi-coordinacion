from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import db, Usuario, Delegacion
from werkzeug.security import generate_password_hash
from utils import registrar_notificacion


usuarios_bp = Blueprint('usuarios_bp', __name__)

@usuarios_bp.route('/usuarios')
@login_required
def listar_usuarios():
    usuarios = Usuario.query.all()
    return render_template('usuarios/listar.html', usuarios=usuarios)

ROLES_MAP = {
    "administrador": "admin",   # sinónimos a la forma canónica
    "admin": "admin",
    "coordinador": "coordinador",
    "secretario": "secretario",
    "delegado": "delegado",
}


ROLES_VALIDOS = set(ROLES_MAP.values())

@usuarios_bp.route('/crear', methods=['GET','POST'])
@login_required
def crear_usuario():
    delegaciones = Delegacion.query.order_by(Delegacion.nombre).all()

    if request.method == 'POST':
        nombre     = (request.form.get('nombre') or '').strip()
        genero     = (request.form.get('genero') or '').strip()
        correo     = (request.form.get('correo') or '').strip().lower()
        delegacion = (request.form.get('delegacion') or '').strip()
        contrasena = (request.form.get('contrasena') or '').strip()
        rol_in     = (request.form.get('rol') or '').strip().lower()
        rol        = ROLES_MAP.get(rol_in, 'delegado')   # <- normaliza

        if not all([nombre, genero, correo, delegacion, contrasena]):
            flash("Completa nombre, género, correo, delegación y contraseña.", "warning")
            return render_template('usuarios/crear.html', delegaciones=delegaciones)

        if rol not in ROLES_VALIDOS:
            flash(f"Rol inválido: {rol_in}", "danger")
            return render_template('usuarios/crear.html', delegaciones=delegaciones)

        if Usuario.query.filter_by(correo=correo).first():
            flash("Ese correo ya está registrado.", "danger")
            return render_template('usuarios/crear.html', delegaciones=delegaciones)

        nuevo = Usuario(
            nombre=nombre,
            genero=genero,
            correo=correo,
            delegacion=delegacion,
            contraseña=generate_password_hash(contrasena),
            rol=rol
        )
        db.session.add(nuevo)
        db.session.commit()

        registrar_notificacion(f"{current_user.nombre} creó usuario '{nuevo.nombre}' ({nuevo.correo}) con rol {nuevo.rol}",
                               tipo="usuario")
        flash("Usuario creado correctamente.", "success")
        return redirect(url_for('usuarios_bp.listar_usuarios'))

    return render_template('usuarios/crear.html', delegaciones=delegaciones)

@usuarios_bp.route('/usuarios/resetear/<int:id>', methods=['POST'])
@login_required
def resetear_contrasena(id):
    usuario = Usuario.query.get_or_404(id)
    nueva = request.form.get('nueva')
    if nueva:
        usuario.contrasena = generate_password_hash(nueva)
        db.session.commit()
        registrar_notificacion(
            f"{current_user.nombre} reseteó la contraseña de '{usuario.nombre}'",
            tipo="usuario"
        )
        flash('Contraseña actualizada', 'success')
    return redirect(url_for('usuarios_bp.listar_usuarios'))

@usuarios_bp.route('/usuarios/eliminar_todos', methods=['POST'])
@login_required
def eliminar_todos_los_usuarios():
    Usuario.query.delete()
    db.session.commit()
    registrar_notificacion(
        f"{current_user.nombre} eliminó TODOS los usuarios",
        tipo="usuario"
    )
    flash('Todos los usuarios han sido eliminados.', 'warning')
    return redirect(url_for('usuarios_bp.listar_usuarios'))

@usuarios_bp.route('/eliminar/<int:id>', methods=['POST'])
@login_required
def eliminar_usuario(id):
    u = Usuario.query.get_or_404(id)

    # 🔒 No borrar al último administrador
    if u.rol == 'admin':
        admins = Usuario.query.filter_by(rol='admin').count()
        if admins <= 1:
            flash("No puedes eliminar al único usuario con rol Administrador.", "warning")
            return redirect(url_for('usuarios_bp.listar_usuarios'))

    # (opcional) No permitir que te borres a ti mismo si eres el único admin
    if u.id == current_user.id and u.rol == 'admin':
        admins = Usuario.query.filter_by(rol='admin').count()
        if admins <= 1:
            flash("No puedes eliminar tu cuenta: eres el único Administrador.", "warning")
            return redirect(url_for('usuarios_bp.listar_usuarios'))

    db.session.delete(u)
    db.session.commit()

    registrar_notificacion(
        f"{current_user.nombre} eliminó el usuario '{u.nombre}' ({u.correo})",
        tipo="usuario"
    )
    flash("Usuario eliminado.", "success")
    return redirect(url_for('usuarios_bp.listar_usuarios'))
